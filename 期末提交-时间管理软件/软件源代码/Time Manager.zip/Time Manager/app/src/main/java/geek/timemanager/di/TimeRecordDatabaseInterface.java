package geek.timemanager.di;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.sql.Timestamp;
import java.util.Vector;

import geek.timemanager.core.Logger;
import geek.timemanager.core.TimeRecord;
import geek.timemanager.core.Timer;

/**
 * Created by 12191 on 2017/5/6.
 */
public class TimeRecordDatabaseInterface {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static final String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" + "TimeRecordDatabase.log"; // Log文件路径与名称
    private static final String DATABASE_PATH =  Environment.getExternalStorageDirectory() + "/TimeManager/TimeManagerDatabase.db"; // 数据库路径

    // 向数据库中插入新的时间记录
    public static int insert(Timestamp startTime, Timestamp endTime, String eventType, String note) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }

        Cursor cursor = sqLiteDatabase.rawQuery("SELECT max(ID) FROM TimeRecord;", null); // 查询最大ID
        cursor.moveToFirst();
        int maxID = cursor.getInt(0); // 获取最大ID
        int recordID = maxID + 1; // 分配时间记录ID
        cursor.close();

        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", recordID);
        contentValues.put("StartTime", startTime.toString());
        if (endTime != null) {
            contentValues.put("EndTime", endTime.toString());
        } else {
            contentValues.put("EndTime", "null");
        }
        contentValues.put("EventType", eventType);
        contentValues.put("Note", note);

        long status = sqLiteDatabase.insert("TimeRecord", null, contentValues);
        sqLiteDatabase.close();
        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "插入时间记录失败，startTime: " + startTime + "; endTime： " + endTime + "eventType: " + eventType + ";");
            return OPERATE_FAIL;
        }

        Logger.Log(LOGFILE_PATH, "插入时间记录，startTime: " + startTime + "; endTime： " + endTime + "eventType: " + eventType + ";");
        return recordID;
    }

    // 向数据库中修改已有的时间记录
    public static int update(int ID, Timestamp startTime, Timestamp endTime, String eventType, String note){
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }

        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", ID);
        contentValues.put("StartTime", startTime.toString());
        contentValues.put("EndTime", endTime.toString());
        contentValues.put("EventType", eventType);
        contentValues.put("Note", note);

        long status = sqLiteDatabase.update("TimeRecord", contentValues, "ID=?", new String[]{ID+""});
        sqLiteDatabase.close();

        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "修改时间记录 " + ID + " 失败");
            return OPERATE_FAIL;
        }

        Logger.Log(LOGFILE_PATH, "修改时间记录 " + ID + " 为：startTime: " + startTime + "; endTime： " + endTime + ";" + "evenType: " + eventType + ";");
        return SUCCESS;
    }

    // 向数据库中删除时间计划
    // ID： 时间计划ID
    public static int delete(int ID) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }

        long status = sqLiteDatabase.delete("TimeRecord", "ID=?", new String[]{ID+""});
        sqLiteDatabase.close();

        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "删除时间记录 " + ID + " 失败");
            return OPERATE_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "删除时间记录 " + ID);
        return SUCCESS;
    }

    // 查找数据库中所有的时间计划
    public static Vector<TimeRecord> query() {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimeRecord WHERE EndTime != ?;", new String[]{"null"});
        Vector<TimeRecord> vector = new Vector<>();
        if (cursor.moveToFirst()) {
            do {
                Timestamp startTime = Timestamp.valueOf(cursor.getString(1));
                Timestamp endTime = Timestamp.valueOf(cursor.getString(2));
                TimeRecord timeRecord = new TimeRecord(cursor.getInt(0), startTime, endTime, cursor.getString(3), cursor.getString(4));
                vector.add(timeRecord);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找所有时间规划");
        return vector;
    }

    // 查找数据库中某一时间段内的时间记录
    public static Vector<TimeRecord> query(Timestamp startTime, Timestamp endTime) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimeRecord WHERE startTime > ? and endTime < ?;", new String[]{startTime.toString(), endTime.toString()});
        Vector<TimeRecord> vector = new Vector<>();
        if (cursor.moveToFirst()) {
            do {
                Timestamp start = Timestamp.valueOf(cursor.getString(1));
                Timestamp end = Timestamp.valueOf(cursor.getString(2));
                TimeRecord timeRecord = new TimeRecord(cursor.getInt(0), start, end, cursor.getString(3), cursor.getString(4));
                vector.add(timeRecord);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找范围内时间记录：" + startTime + "-" + endTime);
        return vector;
    }

    // 查找数据库中某一事件类型的时间记录
    public static Vector<TimeRecord> query(String eventType) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimeRecord WHERE EventType = ? and EndTime != ?;", new String[]{eventType, "null"});
        Vector<TimeRecord> vector = new Vector<>();
        if (cursor.moveToFirst()) {
            do {
                Timestamp start = Timestamp.valueOf(cursor.getString(1));
                Timestamp end = Timestamp.valueOf(cursor.getString(2));
                TimeRecord timeRecord = new TimeRecord(cursor.getInt(0), start, end, cursor.getString(3), cursor.getString(4));
                vector.add(timeRecord);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找特定事件类型类型时间记录：" + eventType);
        return vector;
    }

    // 查找数据库中正在计时的计时器
    public static Vector<Timer> queryTimer() {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimeRecord WHERE EndTime = ?;", new String[]{"null"});
        Vector<Timer> vector = new Vector<>();
        if (cursor.moveToFirst()) {
            do {
                Timestamp start = Timestamp.valueOf(cursor.getString(1));
                Timer timer = new Timer(cursor.getInt(0), start, null, cursor.getString(3));
                vector.add(timer);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找所有正在计时的计时器");
        return vector;
    }


}
