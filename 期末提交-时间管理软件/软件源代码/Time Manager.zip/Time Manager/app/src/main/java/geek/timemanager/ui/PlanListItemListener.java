package geek.timemanager.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import geek.timemanager.core.TimePlan;

/**
 * Created by 12191 on 2017/5/30.
 */

public class PlanListItemListener implements View.OnClickListener {
    public static final String TIME_PLAN_NAME = "time-plan";

    private TimePlan timePlan;

    private Activity activity;

    public PlanListItemListener(Activity activity, TimePlan timePlan) {
        this.activity = activity;
        this.timePlan = timePlan;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(activity, ModifyPlanActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(TIME_PLAN_NAME, timePlan);
        intent.putExtras(bundle);
        activity.startActivity(intent);
    }
}
