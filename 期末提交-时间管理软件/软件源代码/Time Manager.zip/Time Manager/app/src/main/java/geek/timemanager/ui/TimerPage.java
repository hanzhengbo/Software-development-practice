package geek.timemanager.ui;

import android.app.Activity;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.Timer;
import geek.timemanager.core.TimerManager;

/**
 * Created by 12191 on 2017/5/27.
 */

public class TimerPage extends BaseAdapter implements View.OnClickListener{
    private EventTypeManager eventTypeManager;
    private Vector<EventType> eventTypeVector;
    private TimerManager timerManager;
    private Vector<Timer> timerVector;

    private Activity activity;
    private MainViewPagerAdapter mainViewPagerAdapter;

    private View view;
    private ListView listView;

    public TimerPage(Activity activity, MainViewPagerAdapter mainViewPagerAdapter, View view) {
        this.activity = activity;
        this.mainViewPagerAdapter = mainViewPagerAdapter;
        this.view = view;
        this.eventTypeManager = EventTypeManager.getSingletonInstance();
        this.timerManager = TimerManager.getSingletonInstance();
        listView = (ListView) view.findViewById(R.id.id_timer_list);
        listView.setAdapter(this);
    }

    @Override
    public int getCount() {
        eventTypeVector = eventTypeManager.getVector();
        return eventTypeVector.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(activity, R.layout.layout_timer_list_item, null);
        LinearLayout itemLayout = (LinearLayout)view.findViewById(R.id.id_timer_list_item);
        EventType eventType = eventTypeVector.get(position);
        ImageView iconImageView = (ImageView)view.findViewById(R.id.id_timer_list_icon);
        TextView nameTextView = (TextView)view.findViewById(R.id.id_timer_list_name);
        TextView startTextView = (TextView)view.findViewById(R.id.id_timer_list_start);
        Chronometer chronometer =(Chronometer)view.findViewById(R.id.id_timer_list_timer);

        // 获取drawable中图片id
        Class drawable = R.drawable.class;
        Field field;
        int id = 0;
        try {
            field = drawable.getField(eventType.getIcon());
            id = field.getInt(field.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 初始化绘制
        iconImageView.setImageResource(id);
        nameTextView.setText(eventType.getName());
        chronometer.setVisibility(View.INVISIBLE);

        // 事件处理
        itemLayout.setOnClickListener(this);

        // 二次绘制
        timerVector = timerManager.getAllTimer();
        for (Iterator<Timer> iterator = timerVector.iterator(); iterator.hasNext();) {
            Timer timerI = iterator.next();
            if (eventType.getName().equals(timerI.getEventType())) {
                long temp = System.currentTimeMillis() - timerI.getStartTime().getTime();
                chronometer.setBase(SystemClock.elapsedRealtime() - temp);
                chronometer.setVisibility(View.VISIBLE);
                chronometer.start();
                String startTime = String.format("%02d:%02d", timerI.getStartTime().getHours(), timerI.getStartTime().getMinutes());
                startTextView.setText(startTime);
                break;
            }
        }


        return view;
    }

    @Override
    public void onClick(View v) {
        TextView nameTextView = (TextView)v.findViewById(R.id.id_timer_list_name);
        TextView startTextView = (TextView)v.findViewById(R.id.id_timer_list_start);
        Chronometer chronometer = (Chronometer)v.findViewById(R.id.id_timer_list_timer);
        if (chronometer.getVisibility() == View.INVISIBLE) {
            // 计时器未开始计时
            chronometer.setVisibility(View.VISIBLE);
            chronometer.setBase(SystemClock.elapsedRealtime());
            chronometer.start();

            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            String startTime = String.format("%2d:%2d", timestamp.getHours(), timestamp.getMinutes());
            startTextView.setText(startTime);

            timerManager.startTimer(eventTypeManager.getEventTypeByName(nameTextView.getText().toString()));
        } else {
            // 计时器已经计时
            chronometer.stop();
            chronometer.setVisibility(View.INVISIBLE);
            startTextView.setText("");
            timerVector = timerManager.getAllTimer();
            for (Iterator<Timer> iterator = timerVector.iterator(); iterator.hasNext();) {
                Timer timer = iterator.next();
                if (nameTextView.getText().toString().equals(timer.getEventType())) {
                    timerManager.stopTimer(timer);
                    break;
                }
            }
            mainViewPagerAdapter.notifyRecordPage();
        }
    }
}
