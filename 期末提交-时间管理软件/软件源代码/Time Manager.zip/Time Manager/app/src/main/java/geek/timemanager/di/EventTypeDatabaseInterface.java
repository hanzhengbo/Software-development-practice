package geek.timemanager.di;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.util.Vector;

import geek.timemanager.core.EventType;
import geek.timemanager.core.Logger;

/**
 * Created by 12191 on 2017/5/6.
 */
public class EventTypeDatabaseInterface {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static final String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" + "EventTypeDatabase.log"; // Log文件路径与名称
    private static final String DATABASE_PATH =  Environment.getExternalStorageDirectory() + "/TimeManager/TimeManagerDatabase.db"; // 数据库路径

    // 向数据库中插入新的事件类型
    // name: 事件类型名称
    // path: 图标路径
    public static int insert(String name, String path) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH);
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("icon", path);
        long status = sqLiteDatabase.insert("EventType", null, contentValues);
        sqLiteDatabase.close();
        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "插入事件类型失败，name: " + name + "; 图标路径： " + path + ";");
            return OPERATE_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "插入事件类型，name: " + name + "; 图标路径： " + path + ";");
        return SUCCESS;
    }

    // 向数据库中修改已有的事件类型
    // oldName: 旧的事件类型名称
    // newName: 新的事件类型名称
    // newPath: 新的图标路径
    public static int update(String oldName, String newName, String newIcon) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH);
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name", newName);
        contentValues.put("Icon", newIcon);
        long status = sqLiteDatabase.update("EventType", contentValues, "name=?", new String[]{oldName});
        sqLiteDatabase.close();
        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "修改事件类型 " + oldName + " 失败");
            return OPERATE_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "修改事件类型 " + oldName + " 为：name: " + newName + "; icon： " + newIcon + ";");
        return SUCCESS;
    }

    // 向数据库中删除新的事件类型
    // name: 事件类型名称
    // path: 图标路径
    public static int delete(String name) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH);
        long status = sqLiteDatabase.delete("EventType", "name=?", new String[]{name});
        sqLiteDatabase.close();
        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "删除事件类型 " + name + " 失败");
            return OPERATE_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "删除事件类型 " + name);
        return SUCCESS;
    }

    // 查找数据库中所有的事件类型
    public static Vector<EventType> query() {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH);
        Vector<EventType> vector = new Vector<>();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM EventType", null);
        cursor.moveToFirst();
        if (cursor.moveToFirst()) {
            do {
                EventType eventType = new EventType(cursor.getString(0), cursor.getString(1));
                vector.add(eventType);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找所有事件类型");
        return vector;
    }
}
