package geek.timemanager.ui;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/26.
 */

public class MainFragment extends Fragment {

    private Activity activity;
    private View view;

    public ToolBar toolBar;
    public Tab tab;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this.getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, null);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.view = this.getView();
        toolBar = new ToolBar(activity, view);
        tab = new Tab(activity, view);
    }

    @Override
    public void onPause() {
        super.onPause();
    }


}
