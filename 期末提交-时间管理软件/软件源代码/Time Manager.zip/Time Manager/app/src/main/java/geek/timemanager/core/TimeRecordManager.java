package geek.timemanager.core;

import android.os.Environment;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Vector;

import geek.timemanager.di.TimeRecordDatabaseInterface;

/**
 * Created by 12191 on 2017/5/1.
 */
public class TimeRecordManager {
    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static TimeRecordManager timeRecordManager = null; // 单例
    private String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" +  "TimeRecordManager.log"; // Log文件路径与名称
    private Vector<TimeRecord> vector = null; // 保存当天的所有时间记录

    private TimeRecordManager() { // 保护构造函数
        Logger.Log(LOGFILE_PATH, "创建时间记录管理器");
        refreshVector(); // 更新时间记录
    }

    // 获取单例
    public static TimeRecordManager getSingletonInstance() {
        if (timeRecordManager == null) {
            timeRecordManager = new TimeRecordManager();
        }
        return timeRecordManager;
    }

    // 添加时间记录至数据库
    public int add(TimeRecord timeRecord) {
        if (!validate(timeRecord)) { // 若验证失败
            return INFO_LOST;
        }

        int statusCode = TimeRecordDatabaseInterface.insert(timeRecord.getStartTime(), timeRecord.getEndTime(), timeRecord.getEventType(), timeRecord.getNote()); // 更新至数据库
        if (statusCode >= 0) { // 添加成功返回的状态码为ID
            Logger.Log(LOGFILE_PATH, "新增时间记录" + timeRecord.toLog() + "成功");
            timeRecord.setID(statusCode); // 更新ID
        } else {
            Logger.Log(LOGFILE_PATH, "新增时间记录 " + timeRecord.getEventType() + " 失败，状态码：" + statusCode);
        }
        return statusCode;
    }

    // 在数据库中修改时间记录
    public int modify(TimeRecord timeRecord) {
        if (!validate(timeRecord)) { // 若验证失败
            return INFO_LOST;
        }

        if (timeRecord.getID() == -1) { // 时间记录ID不合法
            Logger.Log(LOGFILE_PATH, "修改时间记录失败，ID错误");
            return INFO_LOST;
        }

        int statusCode = TimeRecordDatabaseInterface.update(timeRecord.getID(), timeRecord.getStartTime(), timeRecord.getEndTime(), timeRecord.getEventType(), timeRecord.getNote()); // 更新至数据库
        Logger.Log(LOGFILE_PATH, "修改时间记录: " + timeRecord.toLog() + " 状态： " + statusCode);
        return statusCode;
    }

    // 在数据库中删除时间记录
    public int remove(TimeRecord timeRecord) {
        if (!validate(timeRecord)) { // 若验证失败
            return INFO_LOST;
        }

        if (timeRecord.getID() == -1) { // 时间记录ID不合法
            Logger.Log(LOGFILE_PATH, "删除时间记录失败，ID错误");
            return INFO_LOST;
        }

        int statusCode = TimeRecordDatabaseInterface.delete(timeRecord.getID()); // 更新至数据库
        Logger.Log(LOGFILE_PATH, "删除时间记录: " + timeRecord.toLog() + " " + timeRecord.getEventType() + " 状态： " + statusCode);
        return statusCode;
    }

    // 验证时间记录
    public boolean validate(TimeRecord timeRecord) {
        if (timeRecord == null) { // 若待验证时间记录为空
            Logger.Log(LOGFILE_PATH, "验证时间记录失败，时间记录对象为空");
            return false;
        }
        if (timeRecord.getEventType() == null) { // 若待验证时间记录事件类型为空
            Logger.Log(LOGFILE_PATH, "验证时间记录失败，时间记录事件类型为空");
            return false;
        }
        if (timeRecord.getStartTime() == null) { // 若待验证时间记录起始时间为空
            Logger.Log(LOGFILE_PATH, "验证时间记录失败，时间记录起始时间为空");
            return false;
        }
        if (timeRecord.getStartTime().compareTo(new Timestamp(System.currentTimeMillis())) > 0) { // 若待验证时间记录起始时间后于当前时间
            Logger.Log(LOGFILE_PATH, "验证时间记录失败，时间记录起始时间后于当前时间");
            return false;
        }
        if (timeRecord.getEndTime() != null ) { // 若待验证时间记录结束时间不为空
            if (timeRecord.getStartTime().compareTo(timeRecord.getEndTime()) >= 0) { // 若起始时间后于结束时间
                Logger.Log(LOGFILE_PATH, "验证时间记录失败，时间记录起始时间后于结束时间");
                return false;
            }
        }
        Logger.Log(LOGFILE_PATH, "验证时间记录成功");
        return true;
    }

    // 更新当天的时间记录
    public void refreshVector() {
//        Timestamp todayStart = new Timestamp(System.currentTimeMillis()); // 获取当前时间
//        todayStart.setHours(0); // 设置时间为当天起始时间
//        todayStart.setMinutes(0);
//        todayStart.setSeconds(0);
//        Timestamp todayEnd = new Timestamp(System.currentTimeMillis()); // 获取当前时间
//        todayEnd.setHours(23); // 设置时间为当天结束时间
//        todayEnd.setMinutes(59);
//        todayEnd.setSeconds(59);
//        vector = TimeRecordDatabaseInterface.query(todayStart, todayEnd); // 获取当天时间记录
        vector = TimeRecordDatabaseInterface.query();
        Logger.Log(LOGFILE_PATH, "更新当天时间记录");
    }

    // 获取当天时间记录容器
    public Vector<TimeRecord> getTodayVector() {
        return vector;
    }

    // 查找规定时间内的时间记录(精确到天)
    public Vector<TimeRecord> query(Date dateStart, Date dateEnd) {
        if (dateStart == null && dateEnd == null) {
            Logger.Log(LOGFILE_PATH, "查找时间记录失败，信息不完整");
            return null;
        }
        Timestamp timestampStart = new Timestamp(dateStart.getTime());
        timestampStart.setHours(0); // 设置时间为当天起始时间
        timestampStart.setMinutes(0);
        timestampStart.setSeconds(0);
        Timestamp timestampEnd = new Timestamp(dateEnd.getTime());
        timestampEnd.setHours(23); // 设置时间为当天结束时间
        timestampEnd.setSeconds(59);
        timestampEnd.setMinutes(59);
        Vector<TimeRecord> vector = TimeRecordDatabaseInterface.query(timestampStart, timestampEnd); // 在数据库中查找
        if (vector == null) {
            Logger.Log(LOGFILE_PATH, "查找时间记录失败，请查阅" + LOGFILE_PATH);
        } else {
            Logger.Log(LOGFILE_PATH, "查找时间记录成功");
        }
        return vector;
    }
}
