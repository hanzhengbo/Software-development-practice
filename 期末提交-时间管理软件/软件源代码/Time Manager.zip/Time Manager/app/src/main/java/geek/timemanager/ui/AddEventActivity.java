package geek.timemanager.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;

/**
 * Created by 12191 on 2017/5/30.
 */

public class AddEventActivity extends Activity {
    private EventTypeManager eventTypeManager;
    private EventType eventType;

    private ImageView backImageView;
    private ImageView deleteImageView;
    private ImageView confirmImageView;
    private ListView listView;
    private ModifyEventAdapter addEventAdapter;
    private EditText editText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_modify_event);
        initializeView();
        initializeEvent();
    }

    private void initializeView() {
        backImageView = (ImageView)findViewById(R.id.id_event_back);
        deleteImageView = (ImageView)findViewById(R.id.id_event_delete);
        confirmImageView = (ImageView)findViewById(R.id.id_event_confirm);
        listView = (ListView)findViewById(R.id.id_event_icon_list);
        editText = (EditText)findViewById(R.id.id_modify_event_name);
    }

    private void initializeEvent() {
        eventTypeManager = EventTypeManager.getSingletonInstance();

        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        confirmImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getModifiedEventType();
                if (!ValidateEventType()) {
                    return;
                }
                eventTypeManager.add(eventType);
                finish();
            }
        });

        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");
            }
        });

        addEventAdapter = new ModifyEventAdapter(this);
        listView.setAdapter(addEventAdapter);
    }

    private boolean ValidateEventType() {
        String name = eventType.getName();
        if (name == null || name.equals("")) {
            Toast.makeText(this, "请输入事件名称", Toast.LENGTH_LONG).show();
            return false;
        }

        Vector<EventType> vector = eventTypeManager.getVector();
        for (Iterator<EventType> iterator = vector.iterator(); iterator.hasNext();) {
            if (iterator.next().getName().equals(name)) {
                Toast.makeText(this, "事件名称重复", Toast.LENGTH_LONG).show();
                return false;
            }
        }

        return true;
    }

    private void getModifiedEventType() {
        String icon = addEventAdapter.getIcon();
        String name = editText.getText().toString();
        eventType = new EventType(name, icon);
    }
}
