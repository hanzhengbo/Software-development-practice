package geek.timemanager.core;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by 12191 on 2017/5/1.
 */
public class TimePlan implements Serializable{
    private int ID = -1;
    private Timestamp startTime;
    private Timestamp endTime;
    private String eventType;
    private String note;

    public TimePlan(int ID, Timestamp startTime, Timestamp endTime, String eventType, String note) {
        this.ID = ID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.eventType = eventType;
        this.note = note;
    }

    public TimePlan(Timestamp startTime, Timestamp endTime, String eventType, String note) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.eventType = eventType;
        this.note = note;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String toLog() {
        return "ID：" + ID + " 事件类型：" + eventType + " ";
    }
}
