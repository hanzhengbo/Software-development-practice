package geek.timemanager.ui;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimePlan;

/**
 * Created by 12191 on 2017/5/30.
 */

public class ModifyPlanAdapter extends BaseAdapter {
    private Activity activity;
    private Vector<EventType> vector;

    private TimePlan timePlan;

    private boolean LIST_ON; // 列表是否展开

    private ListView listView;

    public ModifyPlanAdapter(Activity activity, TimePlan timePlan, ListView listView) {
        this.activity = activity;
        this.timePlan = timePlan;
        this.LIST_ON = false;
        this.listView = listView;
        initVector();
    }

    // 初始化vector
    public void initVector() {
        vector = new Vector<>();
        EventTypeManager eventTypeManager = EventTypeManager.getSingletonInstance();
        EventType eventType = eventTypeManager.getEventTypeByName(timePlan.getEventType());
        vector.add(eventType);
    }

    @Override
    public int getCount() {
        return vector.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(activity, R.layout.layout_event_list, null); // 获取XML布局
        ImageView imageView = (ImageView) view.findViewById(R.id.id_event_icon); // 获取事件类型图标
        TextView textView = (TextView) view.findViewById(R.id.id_event_name); // 获取事件类型名称
        final EventType eventType = vector.get(position); // 获取事件类型

        Class drawable = R.drawable.class;
        Field field;
        int id = 0;
        try {
            field = drawable.getField(eventType.getIcon());
            id = field.getInt(field.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        imageView.setImageResource(id);

        textView.setText(eventType.getName());

        view.setClickable(true);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LIST_ON) { // 若列表展开
                    // 修改事件类型
                    timePlan.setEventType(eventType.getName());
                    vector = new Vector<>();
                    vector.add(eventType); // 新建一个只有当前事件类型的容器
                    LIST_ON = false; // 列表关闭
                } else { // 若列表关闭
                    vector = EventTypeManager.getSingletonInstance().getVector(); // 获取包含所有事件类型的容器
                    LIST_ON = true; // 列表展开
                }
                notifyDataSetChanged();
                setListViewHeightBasedOnChildren(listView);
            }
        });
        return view;
    }

    public void setListViewHeightBasedOnChildren(ListView listView) {

        int totalHeight = 0;

        for (int i = 0; i < getCount(); i++) {
            View listItem = getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();

        params.height = totalHeight
                + (listView.getDividerHeight() * (getCount() - 1));

        listView.setLayoutParams(params);
    }

    public boolean isLIST_ON() {
        return LIST_ON;
    }

    public EventType getEventType() {
        return vector.get(0);
    }
}
