package geek.timemanager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.io.File;

import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimePlanManager;
import geek.timemanager.core.TimeRecordManager;
import geek.timemanager.core.TimerManager;
import geek.timemanager.ui.LockService;
import geek.timemanager.ui.SideBar;

public class MainActivity extends AppCompatActivity {

    private SideBar sideBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createFolder();
        createDatabases();
        initializeManagers();
        sideBar = new SideBar(this);
        startService(new Intent(this, LockService.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        sideBar.mainFragment.tab.mainViewPagerAdapter.notifyRecordPage();
        sideBar.mainFragment.tab.mainViewPagerAdapter.notifyPlanPage();
        sideBar.eventTypeManageFragment.notifyEventList();
    }

    // 加载所有管理器
    private void initializeManagers() {
        EventTypeManager.getSingletonInstance();
        TimeRecordManager.getSingletonInstance();
        TimePlanManager.getSingletonInstance();
        TimerManager.getSingletonInstance();
    }

    // 创建文件夹（仅第一次运行时使用）
    private void createFolder() {
        // 判断是否由SD卡读取权限
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            Toast.makeText(this, "无访问SD卡权限！", Toast.LENGTH_LONG);
            return;
        }

        String folderPath =  Environment.getExternalStorageDirectory() + "/TimeManager"; // 获取SD卡路径
        File newFile = new File(folderPath); // 新建文件夹
        if (!newFile.exists()) {
            newFile.mkdirs();
        }
    }

    // 创建数据库（仅第一次运行时使用）
    private void createDatabases() {
        // 判断是否由SD卡读取权限
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            Toast.makeText(this, "无访问SD卡权限！", Toast.LENGTH_LONG);
            return;
        }

        // 获取数据库路径
        String databasePath =  Environment.getExternalStorageDirectory() + "/TimeManager/TimeManagerDatabase.db";

        // 数据库文件
        File databaseFile = new File(databasePath);

        // 不存在该文件则创建数据库以及数据库基表
        SQLiteDatabase sqLiteDatabase;
        String sql;
        if (!databaseFile.exists()) {
            sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(databaseFile, null);
            sql = "CREATE TABLE TimeRecord (" +
                    "    ID        INT      PRIMARY KEY," +
                    "    StartTime DATETIME," +
                    "    EndTime   DATETIME," +
                    "    EventType STRING   REFERENCES EventType (Name)," +
                    "    Note      VARCHAR" +
                    ");";
            sqLiteDatabase.execSQL(sql);
            sql = "CREATE TABLE TimePlan (" +
                    "    ID        INT      PRIMARY KEY," +
                    "    StartTime DATETIME," +
                    "    EndTime   DATETIME," +
                    "    EventType STRING," +
                    "    Note      STRING" +
                    ");";
            sqLiteDatabase.execSQL(sql);
            sql = "CREATE TABLE EventType (" +
                    "    Name VARCHAR PRIMARY KEY," +
                    "    Icon STRING" +
                    ");";
            sqLiteDatabase.execSQL(sql);

            // 创建默认的事件类型
            sql = "INSERT INTO EventType " +
                    "VALUES ('聊天', 'chat')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('编码', 'code')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('修理', 'fix')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('游戏', 'game')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('音乐', 'listen')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('摄影', 'photo')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('旅行', 'travel')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('电视', 'tv')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('上网', 'web')";
            sqLiteDatabase.execSQL(sql);
            sql = "INSERT INTO EventType " +
                    "VALUES ('工作', 'work')";
            sqLiteDatabase.execSQL(sql);
            sqLiteDatabase.close();
        }
    }
}
