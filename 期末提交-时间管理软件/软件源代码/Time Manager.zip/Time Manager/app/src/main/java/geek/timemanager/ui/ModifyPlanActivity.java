package geek.timemanager.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.jjobes.slidedatetimepicker.SlideDateTimeListener;
import com.github.jjobes.slidedatetimepicker.SlideDateTimePicker;

import java.sql.Timestamp;
import java.util.Date;

import geek.timemanager.R;
import geek.timemanager.core.TimePlan;
import geek.timemanager.core.TimePlanManager;

/**
 * Created by 12191 on 2017/5/30.
 */

public class ModifyPlanActivity extends FragmentActivity {
    private TimePlan timePlan;
    private Timestamp startTime;
    private Timestamp endTime;

    private ImageView backImageView;
    private ImageView deleteImageView;
    private ImageView confirmImageView;
    private ListView listView;
    private ModifyPlanAdapter modifyPlanAdapter;
    private LinearLayout linearLayout;
    private TextView dateTextView;
    private TextView startTextView;
    private TextView endTextView;
    private TextView lenTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        getInfo();
        initializeView();
        initializeEvent();
    }

    // Bundle中获取信息
    private void getInfo() {
        Intent intent = this.getIntent();
        timePlan = (TimePlan) intent.getSerializableExtra(PlanListItemListener.TIME_PLAN_NAME);
    }



    // 初始化视图
    private void initializeView() {
        backImageView = (ImageView)findViewById(R.id.id_modify_back);
        deleteImageView = (ImageView)findViewById(R.id.id_modify_delete);
        confirmImageView = (ImageView)findViewById(R.id.id_modify_confirm);
        listView = (ListView)findViewById(R.id.id_modify_list);
        linearLayout = (LinearLayout)findViewById(R.id.id_modify_info);
        dateTextView = (TextView)findViewById(R.id.id_modify_date);
        startTextView = (TextView)findViewById(R.id.id_modify_start);
        endTextView = (TextView)findViewById(R.id.id_modify_end);
        lenTextView = (TextView)findViewById(R.id.id_modify_len);

        startTime = timePlan.getStartTime();
        endTime = timePlan.getEndTime();
        String str = (startTime.getYear() + 1900) + "年" + (startTime.getMonth() + 1) + "月" + (startTime.getDate()) + "日";
        dateTextView.setText(str);
        String start = String.format("%02d:%02d", startTime.getHours(),startTime.getMinutes());
        String end = String.format("%02d:%02d", endTime.getHours(),endTime.getMinutes());
        startTextView.setText(start);
        endTextView.setText(end);
        long length = (endTime.getTime() - startTime.getTime())/60000;
        long hour = length / 60;
        long minute = length % 60;
        str = String.format("%02d:%02d",hour,minute);
        lenTextView.setText(str);
    }

    // 初始化事件
    private void initializeEvent() {
        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePlanManager timePlanManager = TimePlanManager.getSingletonInstance();
                timePlanManager.remove(timePlan);
                finish();
            }
        });

        confirmImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (modifyPlanAdapter.isLIST_ON()) {
                    Toast.makeText(ModifyPlanActivity.this, "请选择事件类型", Toast.LENGTH_LONG).show();
                    return;
                }
                TimePlanManager timePlanManager = TimePlanManager.getSingletonInstance();
                int status = timePlanManager.modify(timePlan);
                if (status != 0) {
                    Toast.makeText(ModifyPlanActivity.this, "修改失败，请检查时间", Toast.LENGTH_LONG);
                }
                finish();
            }
        });

        modifyPlanAdapter = new ModifyPlanAdapter(this, timePlan, listView);
        listView.setAdapter(modifyPlanAdapter);

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ModifyPlanActivity.this, "请选择开始时间", Toast.LENGTH_LONG).show();
                new SlideDateTimePicker.Builder(getSupportFragmentManager())
                        .setListener(new SlideDateTimeListener() {
                            @Override
                            public void onDateTimeSet(Date date) {
                                String start = String.format("%02d:%02d", date.getHours(),date.getMinutes());
                                startTextView.setText(start);
                                startTime = new Timestamp(date.getTime());
                                timePlan.setStartTime(startTime);

                                String str = (startTime.getYear() + 1900) + "年" + (startTime.getMonth() + 1) + "月" + (startTime.getDate()) + "日";
                                dateTextView.setText(str);

                                Toast.makeText(ModifyPlanActivity.this, "请选择结束时间", Toast.LENGTH_LONG).show();
                                new SlideDateTimePicker.Builder(getSupportFragmentManager())
                                        .setListener(new SlideDateTimeListener() {
                                            @Override
                                            public void onDateTimeSet(Date date) {
                                                String end = String.format("%02d:%02d", date.getHours(),date.getMinutes());
                                                endTextView.setText(end);
                                                endTime = new Timestamp(date.getTime());
                                                timePlan.setEndTime(endTime);

                                                if (startTime.after(endTime)) {
                                                    Toast.makeText(ModifyPlanActivity.this, "开始时间后于结束时间", Toast.LENGTH_LONG).show();
                                                    return;
                                                }

                                                long length = (endTime.getTime() - startTime.getTime())/60000;
                                                long hour = length / 60;
                                                long minute = length % 60;
                                                lenTextView.setText(String.format("%02d:%02d",hour,minute));
                                            }
                                        })
                                        .setInitialDate(new Date())
                                        .build()
                                        .show();
                            }
                        })
                        .setInitialDate(new Date())
                        .build()
                        .show();
            }
        });
    }
}
