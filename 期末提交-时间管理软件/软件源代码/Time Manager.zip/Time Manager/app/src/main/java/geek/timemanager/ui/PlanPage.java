package geek.timemanager.ui;

import android.app.Activity;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimePlan;
import geek.timemanager.core.TimePlanManager;

/**
 * Created by 12191 on 2017/5/30.
 */

public class PlanPage extends BaseAdapter implements View.OnClickListener {
    private TimePlanManager timePlanManager = TimePlanManager.getSingletonInstance();
    private Vector<TimePlan> planVector;

    private Activity activity;
    private MainViewPagerAdapter mainViewPagerAdapter;

    private Date startDate;
    private Date endDate;

    private View view;
    private ListView listView;

    public PlanPage(Activity activity, MainViewPagerAdapter mainViewPagerAdapter, View view) {
        this.activity = activity;
        this.mainViewPagerAdapter = mainViewPagerAdapter;
        this.view = view;
        listView = (ListView)view.findViewById(R.id.id_plan_list);
        listView.setAdapter(this);
    }

    @Override
    public int getCount() {
        timePlanManager.refreshVector();
        planVector = timePlanManager.getTodayVector();
        return planVector.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(activity, R.layout.layout_plan_list_item, null);
        ImageView iconImageView = (ImageView)view.findViewById(R.id.id_plan_list_icon); // 左侧图片
        LinearLayout middleLinearLayout = (LinearLayout)view.findViewById(R.id.id_plan_list_middle);
        TextView nameTextView = (TextView)middleLinearLayout.findViewById(R.id.id_plan_list_name); // 事件类型
        TextView timeTextView = (TextView)middleLinearLayout.findViewById(R.id.id_plan_list_time); // 起止时间
        TextView lenTextView = (TextView)view.findViewById(R.id.id_plan_list_len); // 时间长度
        TimePlan timePlan = planVector.get(position);
        EventTypeManager eventTypeManager = EventTypeManager.getSingletonInstance(); // 获取事件管理器
        EventType eventType = eventTypeManager.getEventTypeByName(timePlan.getEventType());

        Class drawable = R.drawable.class;
        Field field;
        int id = 0;
        try {
            field = drawable.getField(eventType.getIcon());
            id = field.getInt(field.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        iconImageView.setImageResource(id);

        nameTextView.setText(timePlan.getEventType());

        Timestamp startTime = timePlan.getStartTime();
        Timestamp endTime = timePlan.getEndTime();

        String str = String.format("%02d:%02d - %02d:%02d", startTime.getHours(), startTime.getMinutes(), endTime.getHours(), endTime.getMinutes());
        timeTextView.setText(str);

        long length = (endTime.getTime() - startTime.getTime())/60000;
        long hour = length / 60;
        long minute = length % 60;
        str = String.format("%02d:%02d",hour,minute);
        lenTextView.setText(str);

        view.setOnClickListener(new PlanListItemListener(activity, timePlan));

        return view;
    }

    @Override
    public void onClick(View v) {

    }
}
