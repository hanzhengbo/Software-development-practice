package geek.timemanager.core;

import java.sql.Timestamp;

/**
 * Created by 12191 on 2017/5/5.
 */
public class Timer {
    private int ID = -1;
    private Timestamp startTime = null;
    private Timestamp endTime = null;
    private String eventType = null;

    // 启动计时器
    public Timer(String eventType) {
        startTime = new Timestamp(System.currentTimeMillis()); // 当前时间为启动时间
        this.eventType = eventType;
    }

    // 自定义启动时间启动计时器
    public Timer(int ID, Timestamp startTime, Timestamp endTime, String eventType) {
        this.ID = ID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.eventType = eventType;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public void stopTiming() {
        this.endTime = new Timestamp(System.currentTimeMillis()); // 获取当前系统时间
    }

    public String toLog() {
        return "ID: " + ID + "事件类型：" + eventType + " ";
    }
}
