package geek.timemanager.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.jjobes.slidedatetimepicker.SlideDateTimeListener;
import com.github.jjobes.slidedatetimepicker.SlideDateTimePicker;

import java.sql.Timestamp;
import java.util.Date;

import geek.timemanager.R;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimeRecord;
import geek.timemanager.core.TimeRecordManager;

/**
 * Created by 12191 on 2017/5/29.
 */

public class AddRecordActivity extends FragmentActivity{
    private TimeRecord timeRecord;
    private Timestamp startTime;
    private Timestamp endTime;

    private ImageView backImageView;
    private ImageView deleteImageView;
    private ImageView confirmImageView;
    private ListView listView;
    private ModifyRecordAdapter addRecordAdapter;
    private LinearLayout linearLayout;
    private TextView dateTextView;
    private TextView startTextView;
    private TextView endTextView;
    private TextView lenTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        initializeView();
        initializeEvent();
    }

    // 初始化视图
    private void initializeView() {
        backImageView = (ImageView)findViewById(R.id.id_modify_back);
        deleteImageView = (ImageView)findViewById(R.id.id_modify_delete);
        confirmImageView = (ImageView)findViewById(R.id.id_modify_confirm);
        listView = (ListView)findViewById(R.id.id_modify_list);
        linearLayout = (LinearLayout)findViewById(R.id.id_modify_info);
        dateTextView = (TextView)findViewById(R.id.id_modify_date);
        startTextView = (TextView)findViewById(R.id.id_modify_start);
        endTextView = (TextView)findViewById(R.id.id_modify_end);
        lenTextView = (TextView)findViewById(R.id.id_modify_len);
    }

    private void initializeEvent() {
        startTime = new Timestamp(System.currentTimeMillis());
        endTime = new Timestamp(System.currentTimeMillis());
        timeRecord = new TimeRecord(startTime, endTime, EventTypeManager.getSingletonInstance().getVector().get(0).getName(), null);

        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeRecordManager timeRecordManager = TimeRecordManager.getSingletonInstance();
                finish();
            }
        });

        confirmImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (addRecordAdapter.isLIST_ON()) {
                    Toast.makeText(AddRecordActivity.this, "请选择事件类型", Toast.LENGTH_LONG).show();
                    return;
                }
                TimeRecordManager timeRecordManager = TimeRecordManager.getSingletonInstance();
                int status = timeRecordManager.add(timeRecord);
                if (status != 0) {
                    Toast.makeText(AddRecordActivity.this, "修改失败，请检查时间", Toast.LENGTH_LONG);
                }
                finish();
            }
        });

        addRecordAdapter = new ModifyRecordAdapter(this, timeRecord, listView);
        listView.setAdapter(addRecordAdapter);

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AddRecordActivity.this, "请选择开始时间", Toast.LENGTH_LONG).show();
                new SlideDateTimePicker.Builder(getSupportFragmentManager())
                        .setListener(new SlideDateTimeListener() {
                            @Override
                            public void onDateTimeSet(Date date) {
                                String start = String.format("%02d:%02d", date.getHours(),date.getMinutes());
                                startTextView.setText(start);
                                startTime = new Timestamp(date.getTime());
                                timeRecord.setStartTime(startTime);

                                String str = (startTime.getYear() + 1900) + "年" + (startTime.getMonth() + 1) + "月" + (startTime.getDate()) + "日";
                                dateTextView.setText(str);

                                Toast.makeText(AddRecordActivity.this, "请选择结束时间", Toast.LENGTH_LONG).show();
                                new SlideDateTimePicker.Builder(getSupportFragmentManager())
                                        .setListener(new SlideDateTimeListener() {
                                            @Override
                                            public void onDateTimeSet(Date date) {
                                                String end = String.format("%02d:%02d", date.getHours(),date.getMinutes());
                                                endTextView.setText(end);
                                                endTime = new Timestamp(date.getTime());
                                                timeRecord.setEndTime(endTime);

                                                if (startTime.after(endTime)) {
                                                    Toast.makeText(AddRecordActivity.this, "开始时间后于结束时间", Toast.LENGTH_LONG).show();
                                                    return;
                                                }

                                                long length = (endTime.getTime() - startTime.getTime())/60000;
                                                long hour = length / 60;
                                                long minute = length % 60;
                                                lenTextView.setText(String.format("%02d:%02d",hour,minute));
                                            }
                                        })
                                        .setInitialDate(new Date())
                                        .build()
                                        .show();
                            }
                        })
                        .setInitialDate(new Date())
                        .build()
                        .show();
            }
        });
    }
}
