package geek.timemanager.ui;

import android.app.Activity;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/25.
 */

public class ToolBar implements View.OnClickListener {

    private Activity activity;
    private View view;
    private Button sideButton;

    public ToolBar(Activity activity, View view) {
        this.activity = activity;
        this.view = view;
        this.sideButton = (Button)view.findViewById(R.id.id_layout_toolbar_left);
        this.sideButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        DrawerLayout drawerLayout = (DrawerLayout)activity.findViewById(R.id.id_activity_main);
        if (drawerLayout.isDrawerOpen(Gravity.START)) {
            drawerLayout.closeDrawer(Gravity.START);
        } else {
            drawerLayout.openDrawer(Gravity.START);
        }
    }
}
