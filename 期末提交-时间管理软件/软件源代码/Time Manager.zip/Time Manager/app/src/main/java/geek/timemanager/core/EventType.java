package geek.timemanager.core;

import java.io.Serializable;

/**
 * Created by 12191 on 2017/5/1.
 */
public class EventType implements Serializable{
    private String name; // 事件类型名称
    private String icon; // 事件类型图标路径

    public EventType(String name, String icon) {
        this.name = name;
        this.icon = icon;
    }

    // Getters and Setters;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public String toString() {
        return name;
    }

    public String toLog() {
        return "名称：" + name + " ";
    }
}
