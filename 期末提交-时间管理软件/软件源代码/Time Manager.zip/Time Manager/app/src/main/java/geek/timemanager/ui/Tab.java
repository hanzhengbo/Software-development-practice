package geek.timemanager.ui;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/26.
 */

public class Tab implements View.OnClickListener, ViewPager.OnPageChangeListener{

    public static final int TIMER_PAGE = 0;
    public static final int RECORD_PAGE = 1;
    public static final int PLAN_PAGE = 2;
    public static final int COUNT_PAGE = 3;

    private Activity activity;
    private View view;

    private LinearLayout midLinearLayout;
    private Button toolBarRightButton;

    private LinearLayout timerLayout;
    private ImageView timerImageView;
    private TextView timerTextView;
    private View timerView;

    private LinearLayout recordLayout;
    private ImageView recordImageView;
    private TextView recordTextView;
    private View recordView;

    private LinearLayout planLayout;
    private ImageView planImageView;
    private TextView planTextView;
    private View planView;

    private LinearLayout countLayout;
    private ImageView countImageView;
    private TextView countTextView;
    private View countView;

    private List<View> viewList;
    private ViewPager viewPager;

    public MainViewPagerAdapter mainViewPagerAdapter;

    public Tab(Activity activity, View view) {
        this.activity = activity;
        this.view = view;
        initializeView();
        initializeEvent();
    }

    // 设置首页为第一页
    public void setFirstPage() {
        timerImageView.setImageResource(R.drawable.ic_timer_blue_18dp);
        timerTextView.setTextColor(activity.getResources().getColor(R.color.colorTabBlue));
        viewPager.setCurrentItem(TIMER_PAGE);
    }

    // 初始化视图
    public void initializeView() {
        midLinearLayout = (LinearLayout)activity.findViewById(R.id.id_layout_toolbar_mid);
        toolBarRightButton = (Button)activity.findViewById(R.id.id_layout_toolbar_right);

        timerLayout = (LinearLayout)view.findViewById(R.id.id_tab_timer);
        timerImageView = (ImageView)view.findViewById(R.id.id_tab_timer_pic);
        timerTextView = (TextView)view.findViewById(R.id.id_tab_timer_text);
        timerView = View.inflate(activity, R.layout.layout_timer, null);

        recordLayout = (LinearLayout)view.findViewById(R.id.id_tab_time_record);
        recordImageView = (ImageView)view.findViewById(R.id.id_tab_time_record_pic);
        recordTextView = (TextView)view.findViewById(R.id.id_tab_time_record_text);
        recordView = View.inflate(activity, R.layout.layout_time_record, null);

        planLayout = (LinearLayout)view.findViewById(R.id.id_tab_time_plan);
        planImageView = (ImageView)view.findViewById(R.id.id_tab_time_plan_pic);
        planTextView = (TextView)view.findViewById(R.id.id_tab_time_plan_text);
        planView = View.inflate(activity,R.layout.layout_time_plan, null);

        countLayout = (LinearLayout)view.findViewById(R.id.id_tab_time_count);
        countImageView = (ImageView)view.findViewById(R.id.id_tab_time_count_pic);
        countTextView = (TextView)view.findViewById(R.id.id_tab_time_count_text);
        countView = View.inflate(activity, R.layout.layout_time_count, null);

        viewList = new ArrayList<>();
        viewList.add(timerView);
        viewList.add(recordView);
        viewList.add(planView);
        viewList.add(countView);

        viewPager = (ViewPager)view.findViewById(R.id.id_main_viewpager);

        setFirstPage();
    }

    // 初始化事件
    public void initializeEvent() {
        mainViewPagerAdapter = new MainViewPagerAdapter(activity, viewList);
        viewPager.setAdapter(mainViewPagerAdapter);
        viewPager.addOnPageChangeListener(this);

        timerLayout.setOnClickListener(this);
        recordLayout.setOnClickListener(this);
        planLayout.setOnClickListener(this);
        countLayout.setOnClickListener(this);
    }

    // 重置按钮
    private void restartButton() {
        timerImageView.setImageResource(R.drawable.ic_timer_white_18dp);
        timerTextView.setTextColor(activity.getResources().getColor(R.color.colorMainTextWhite));
        recordImageView.setImageResource(R.drawable.ic_time_record_white_18dp);
        recordTextView.setTextColor(activity.getResources().getColor(R.color.colorMainTextWhite));
        planImageView.setImageResource(R.drawable.ic_time_plan_white_18dp);
        planTextView.setTextColor(activity.getResources().getColor(R.color.colorMainTextWhite));
        countImageView.setImageResource(R.drawable.ic_time_count_white_18dp);
        countTextView.setTextColor(activity.getResources().getColor(R.color.colorMainTextWhite));
    }

    // 设置ToolBar文字
    private void setToolBarText(TextView textView, String text) {
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        textView.setTextColor(0xFFFFFFFF);
    }

    // ToolBar设置为普通样式
    private void setNormalToolBar() {
        toolBarRightButton.setVisibility(View.INVISIBLE);

        midLinearLayout.removeAllViews();
        TextView textView = new TextView(activity);

        int width = midLinearLayout.getWidth();
        int height = midLinearLayout.getHeight();
        textView.setWidth(width);
        textView.setHeight(height);

        setToolBarText(textView, "Time Manager");

        midLinearLayout.addView(textView);
    }

    // ToolBar设置为时间样式
    private void setTimeToolBar() {
        setNormalToolBar();
        toolBarRightButton.setVisibility(View.VISIBLE);
//
//        midLinearLayout.removeAllViews();
//        TextView startTextView = new TextView(activity);
//        TextView toTextView = new TextView(activity);
//        TextView endTextView = new TextView(activity);
//
//        int width = midLinearLayout.getWidth();
//        int height = midLinearLayout.getHeight();
//        Double temp;
//        temp = 0.45*width;  startTextView.setWidth(temp.intValue());
//        temp = 0.1*width; toTextView.setWidth(temp.intValue());
//        temp = 0.45*width; endTextView.setWidth(temp.intValue());
//        startTextView.setHeight(height);
//        toTextView.setHeight(height);
//        endTextView.setHeight(height);
//
//        startTextView.setId(R.id.id_record_list_start);
//        endTextView.setId(R.id.id_record_list_end);
//        startTextView.setOnClickListener(mainViewPagerAdapter.recordPage);
//        endTextView.setOnClickListener(mainViewPagerAdapter.recordPage);
//
//        Date date = new Date(System.currentTimeMillis());
//        String str = (date.getYear() + 1900) + "-" +
//                (date.getMonth() + 1) + "-" +
//                date.getDate();
//        setToolBarText(startTextView, str);
//        setToolBarText(toTextView, "-");
//        setToolBarText(endTextView, str);
//
//        midLinearLayout.addView(startTextView);
//        midLinearLayout.addView(toTextView);
//        midLinearLayout.addView(endTextView);
    }

    // 选中计时页面
    private void selectTimerPage() {
        setNormalToolBar();
        timerImageView.setImageResource(R.drawable.ic_timer_blue_18dp);
        timerTextView.setTextColor(activity.getResources().getColor(R.color.colorTabBlue));
        viewPager.setCurrentItem(TIMER_PAGE);
    }

    // 选中记录页面
    private void selectRecordPage() {
        setTimeToolBar();
        recordImageView.setImageResource(R.drawable.ic_time_record_blue_18dp);
        recordTextView.setTextColor(activity.getResources().getColor(R.color.colorTabBlue));
        viewPager.setCurrentItem(RECORD_PAGE);
        toolBarRightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, AddRecordActivity.class);
                activity.startActivity(intent);
            }
        });
    }

    // 选中规划页面
    private void selectPlanPage() {
        setTimeToolBar();
        planImageView.setImageResource(R.drawable.ic_time_plan_blue_18dp);
        planTextView.setTextColor(activity.getResources().getColor(R.color.colorTabBlue));
        viewPager.setCurrentItem(PLAN_PAGE);
        toolBarRightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, AddPlanActivity.class);
                activity.startActivity(intent);
            }
        });
    }

    // 选中统计页面
    private void selectCountPage() {
        setNormalToolBar();
        countImageView.setImageResource(R.drawable.ic_time_count_blue_18dp);
        countTextView.setTextColor(activity.getResources().getColor(R.color.colorTabBlue));
        viewPager.setCurrentItem(COUNT_PAGE);
    }

    @Override
    public void onClick(View v) {
        restartButton();
        switch (v.getId()) {
            case R.id.id_tab_timer:
                selectTimerPage();
                break;
            case R.id.id_tab_time_record:
                selectRecordPage();
                break;
            case R.id.id_tab_time_plan:
                selectPlanPage();
                break;
            case R.id.id_tab_time_count:
                selectCountPage();
                break;
                default:
                    break;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        restartButton();
        switch (position) {
            case TIMER_PAGE:
                selectTimerPage();
                break;
            case RECORD_PAGE:
                selectRecordPage();
                break;
            case PLAN_PAGE:
                selectPlanPage();
                break;
            case COUNT_PAGE:
                selectCountPage();
                break;
            default:
                break;
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
