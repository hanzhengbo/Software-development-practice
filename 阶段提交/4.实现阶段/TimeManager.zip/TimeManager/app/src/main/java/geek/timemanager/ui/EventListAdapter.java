package geek.timemanager.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;

/**
 * Created by 12191 on 2017/5/29.
 */

public class EventListAdapter extends BaseAdapter{
    public static final String EVENT_TYPE_NAME = "event-type";

    private EventTypeManager eventTypeManager;
    private Vector<EventType> eventTypeVector;

    private Activity activity;

    public EventListAdapter(Activity activity) {
        this.activity = activity;
        eventTypeManager = EventTypeManager.getSingletonInstance();
    }

    @Override
    public int getCount() {
        eventTypeVector = eventTypeManager.getVector();
        return eventTypeVector.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(activity, R.layout.layout_event_list, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.id_event_icon); // 获取事件类型图标
        TextView textView = (TextView) view.findViewById(R.id.id_event_name); // 获取事件类型名称
        final EventType eventType = eventTypeVector.get(position); // 获取事件类型

        Class drawable = R.drawable.class;
        Field field;
        int id = 0;
        try {
            field = drawable.getField(eventType.getIcon());
            id = field.getInt(field.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        imageView.setImageResource(id);

        textView.setText(eventType.getName());

        view.setClickable(true);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, ModifyEventActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(EVENT_TYPE_NAME, eventType);
                intent.putExtras(bundle);
                activity.startActivity(intent);
            }
        });
        return view;
    }
}
