package geek.timemanager.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimePlan;
import geek.timemanager.core.TimeRecord;
import geek.timemanager.di.TimePlanDatabaseInterface;
import geek.timemanager.di.TimeRecordDatabaseInterface;

/**
 * Created by 12191 on 2017/5/30.
 */

public class MyLockScreenActivity extends Activity{
    private PieChart recordPieChart;
    private PieChart planPieChart;

    private TextView recordTextView;
    private TextView planTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        setContentView(R.layout.layout_time_count);
        getRecordView();
        getPlanView();
    }

    public void getRecordView() {
        recordPieChart = (PieChart)findViewById(R.id.id_count_record_chart);
        recordTextView = (TextView)findViewById(R.id.id_count_record_text);
        EventTypeManager eventTypeManager = EventTypeManager.getSingletonInstance();
        Vector<EventType> eventTypeVector = eventTypeManager.getVector(); // 获取事件类型容器
        int count = eventTypeVector.size();
        String[] name = new String[count]; // 事件类型名称
        long[] lens = new long[count]; // 时间长度数组
        long total = 0; // 总时间长度
        int temp = 0;
        // 遍历容器获得各事件类型时间长度
        for (Iterator<EventType> iterator = eventTypeVector.iterator(); iterator.hasNext();) {
            EventType eventType = iterator.next();
            Vector<TimeRecord> timeRecordVector = TimeRecordDatabaseInterface.query(eventType.getName());
            lens[temp] = 0;
            for (Iterator<TimeRecord> i = timeRecordVector.iterator(); i.hasNext();) {
                TimeRecord timeRecord = i.next();
                lens[temp] += timeRecord.getEndTime().getTime() - timeRecord.getStartTime().getTime();
            }
            name[temp] = eventType.getName(); // 获取名称
            total += lens[temp]; // 总时间长度增加
            temp++;
        }

        // 获取占比
        float[] data = new float[count];
        ArrayList<Entry> arrayList = new ArrayList<>(); // pie datas
        // 获取饼图数据
        for (int i = 0; i < count; i++) {
            data[i] =Float.parseFloat((lens[i] * 1.0 / total)+"");
            arrayList.add(new Entry(data[i], i));
        }

        String text = "";
        for (int i = 0; i < count; i++) {
            long length = lens[i]/60000;
            long hour = length / 60;
            long minute = length % 60;
            text = text + String.format("%s:%02dh%02dm\n", name[i], hour, minute);
        }
        recordTextView.setText(text);

        // 颜色设置
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(0xFFFFCC99);
        colors.add(0xFFFFFF99);
        colors.add(0xFF99CC99);
        PieDataSet pieDataSet = new PieDataSet(arrayList , "百分比占");
        pieDataSet.setColors(colors); // 设置图形颜色
        PieData pieData = new PieData(name, pieDataSet);

        // 显示饼图
        recordPieChart.setData(pieData);
        recordPieChart.setRotationEnabled(false);
        recordPieChart.invalidate();
    }

    public void getPlanView() {
        planPieChart = (PieChart)findViewById(R.id.id_count_plan_chart);
        planTextView = (TextView)findViewById(R.id.id_count_plan_text);
        EventTypeManager eventTypeManager = EventTypeManager.getSingletonInstance();
        Vector<EventType> eventTypeVector = eventTypeManager.getVector(); // 获取事件类型容器
        int count = eventTypeVector.size();
        String[] name = new String[count]; // 事件类型名称
        long[] lens = new long[count]; // 时间长度数组
        long total = 0; // 总时间长度
        int temp = 0;
        // 遍历容器获得各事件类型时间长度
        for (Iterator<EventType> iterator = eventTypeVector.iterator(); iterator.hasNext();) {
            EventType eventType = iterator.next();
            Vector<TimePlan> timePlanVector = TimePlanDatabaseInterface.query(eventType.getName());
            lens[temp] = 0;
            for (Iterator<TimePlan> i = timePlanVector.iterator(); i.hasNext();) {
                TimePlan timePlan = i.next();
                lens[temp] += timePlan.getEndTime().getTime() - timePlan.getStartTime().getTime();
            }
            name[temp] = eventType.getName(); // 获取名称
            total += lens[temp]; // 总时间长度增加
            temp++;
        }

        // 获取占比
        float[] data = new float[count];
        ArrayList<Entry> arrayList = new ArrayList<>(); // pie datas
        // 获取饼图数据
        for (int i = 0; i < count; i++) {
            data[i] =Float.parseFloat((lens[i] * 1.0 / total)+"");
            arrayList.add(new Entry(data[i], i));
        }

        String text = "";
        for (int i = 0; i < count; i++) {
            long length = lens[i]/60000;
            long hour = length / 60;
            long minute = length % 60;
            text = text + String.format("%s:%02dh%02dm\n", name[i], hour, minute);
        }
        planTextView.setText(text);

        // 颜色设置
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(0xFFFFCC99);
        colors.add(0xFFFFFF99);
        colors.add(0xFF99CC99);
        PieDataSet pieDataSet = new PieDataSet(arrayList , "百分比占");
        pieDataSet.setColors(colors); // 设置图形颜色
        PieData pieData = new PieData(name, pieDataSet);

        // 显示饼图
        planPieChart.setData(pieData);
        planPieChart.setRotationEnabled(false);
        planPieChart.invalidate();
    }
}