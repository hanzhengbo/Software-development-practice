package geek.timemanager.di;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.sql.Timestamp;
import java.util.Vector;

import geek.timemanager.core.Logger;
import geek.timemanager.core.TimePlan;

/**
 * Created by 12191 on 2017/5/6.
 */
public class TimePlanDatabaseInterface {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static final String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" + "TimePlanDatabase.log"; // Log文件路径与名称
    private static final String DATABASE_PATH =  Environment.getExternalStorageDirectory() + "/TimeManager/TimeManagerDatabase.db"; // 数据库路径

    // 向数据库中插入新的事件计划
    public static int insert(Timestamp startTime, Timestamp endTime, String eventType, String note) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT max(ID) FROM TimePlan;", null); // 查询最大ID
        cursor.moveToFirst();
        int maxID = cursor.getInt(0); // 获取最大ID
        int planID = maxID + 1; // 分配时间计划ID
        cursor.close();

        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", planID);
        contentValues.put("StartTime", startTime.toString());
        contentValues.put("EndTime", endTime.toString());
        contentValues.put("EventType", eventType);
        contentValues.put("Note", note);

        long status = sqLiteDatabase.insert("TimePlan", null, contentValues);
        sqLiteDatabase.close();
        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "插入时间计划失败，startTime: " + startTime + "; endTime： " + endTime + "eventType: " + eventType + ";");
            return OPERATE_FAIL;
        }

        Logger.Log(LOGFILE_PATH, "插入时间计划，startTime: " + startTime + "; endTime： " + endTime + "eventType: " + eventType + ";");
        return planID;
    }

    // 向数据库中修改已有的时间计划
    public static int update(int ID, Timestamp startTime, Timestamp endTime, String eventType, String note) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }

        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", ID);
        contentValues.put("StartTime", startTime.toString());
        contentValues.put("EndTime", endTime.toString());
        contentValues.put("EventType", eventType);
        contentValues.put("Note", note);

        long status = sqLiteDatabase.update("TimePlan", contentValues, "ID=?", new String[]{ID+""});
        sqLiteDatabase.close();

        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "修改时间计划 " + ID + " 失败");
            return OPERATE_FAIL;
        }

        Logger.Log(LOGFILE_PATH, "修改时间计划 " + ID + " 为：startTime: " + startTime + "; endTime： " + endTime + ";" + "evenType: " + eventType + ";");
        return SUCCESS;
    }

    // 向数据库中删除时间计划
    // ID： 时间计划ID
    public static int delete(int ID) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return CONNECT_FAIL;
        }

        long status = sqLiteDatabase.delete("TimePlan", "ID=?", new String[]{ID+""});
        sqLiteDatabase.close();

        if (status < 0) {
            Logger.Log(LOGFILE_PATH, "删除事件类型 " + ID + " 失败");
            return OPERATE_FAIL;
        }
        Logger.Log(LOGFILE_PATH, "删除事件类型 " + ID);
        return SUCCESS;
    }

    // 查找数据库中所有的时间计划
    public static Vector<TimePlan> query() {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimePlan;", null);
        Vector<TimePlan> vector = new Vector<>();
        if (cursor.moveToFirst()) {
            do {
                Timestamp startTime = Timestamp.valueOf(cursor.getString(1));
                Timestamp endTime = Timestamp.valueOf(cursor.getString(2));
                TimePlan timePlan = new TimePlan(cursor.getInt(0), startTime, endTime, cursor.getString(3), cursor.getString(4));
                vector.add(timePlan);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找所有时间规划");
        return vector;
    }

    // 查找数据库中某一时间段内的时间计划
    public static Vector<TimePlan> query(Timestamp startTime, Timestamp endTime) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Vector<TimePlan> vector = new Vector<>();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimePlan WHERE startTime > ? and endTime < ?;", new String[]{startTime.toString(), endTime.toString()});
        if (cursor.moveToFirst()) {
            do {
                Timestamp start = Timestamp.valueOf(cursor.getString(1));
                Timestamp end = Timestamp.valueOf(cursor.getString(2));
                TimePlan timePlan = new TimePlan(cursor.getInt(0), start, end, cursor.getString(3), cursor.getString(4));
                vector.add(timePlan);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找范围内时间计划：" + startTime + "-" + endTime);
        return vector;
    }

    // 查找数据库中某一事件类型的时间计划
    public static Vector<TimePlan> query(String eventType) {
        SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(DATABASE_PATH, null);
        if (sqLiteDatabase == null) {
            Logger.Log(LOGFILE_PATH, "连接到数据库:" + DATABASE_PATH + "失败");
            return null;
        }
        Vector<TimePlan> vector = new Vector<>();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM TimePlan WHERE EventType = ?;", new String[]{eventType});
        if (cursor.moveToFirst()) {
            do {
                Timestamp start = Timestamp.valueOf(cursor.getString(1));
                Timestamp end = Timestamp.valueOf(cursor.getString(2));
                TimePlan timePlan = new TimePlan(cursor.getInt(0), start, end, cursor.getString(3), cursor.getString(4));
                vector.add(timePlan);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Logger.Log(LOGFILE_PATH, "查找特定事件类型类型时间计划：" + eventType);
        return vector;
    }
}
