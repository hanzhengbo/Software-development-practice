package geek.timemanager.ui;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/30.
 */

public class ModifyEventAdapter extends BaseAdapter{
    private Vector<String> iconVector;
    private Vector<String> descriptionVector;
    private int iconPosition;

    private Activity activity;


    public ModifyEventAdapter(Activity activity) {
        this.activity = activity;
        iconPosition = 0;
        getVectors();
    }

    public ModifyEventAdapter(String icon, Activity activity) {
        iconPosition = 0;
        getVectors();
        for (int i = 0; i < iconVector.size(); i++) {
            if (iconVector.get(i).equals(icon)) {
                iconPosition = i;
                break;
            }
        }
        this.activity = activity;
    }

    private void getVectors() {
        Pictures pictures = Pictures.getSingletonInstances();
        iconVector = pictures.getIconVector();
        descriptionVector = pictures.getDescriptionVector();
    }

    private int getId(String name) {
        Class drawable = R.drawable.class;
        Field field;
        int id = 0;
        try {
            field = drawable.getField(name);
            id = field.getInt(field.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return id;
    }

    public String getIcon() {
        return iconVector.get(iconPosition);
    }

    @Override
    public int getCount() {
        return iconVector.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final View view = View.inflate(activity, R.layout.layout_event_list, null);
        ImageView iconImageView = (ImageView)view.findViewById(R.id.id_event_icon);
        TextView descriptionTextView = (TextView)view.findViewById(R.id.id_event_name);
        iconImageView.setImageResource(getId(iconVector.get(position)));
        descriptionTextView.setText(descriptionVector.get(position));

        if (position == iconPosition) {
            view.setBackgroundColor(activity.getResources().getColor(R.color.colorTabBlue));
        }

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconPosition = position;
                notifyDataSetChanged();
            }
        });

        return view;
    }
}
