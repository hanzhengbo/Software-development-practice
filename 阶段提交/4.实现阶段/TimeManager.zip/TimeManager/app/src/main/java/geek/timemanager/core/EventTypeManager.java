package geek.timemanager.core;

import android.os.Environment;

import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.di.EventTypeDatabaseInterface;

/**
 * Created by 12191 on 2017/5/1.
 */
public class EventTypeManager {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static EventTypeManager eventTypeManager = null; // 单例
    private String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" + "EventTypeManager.log"; // Log文件路径与名称
    private Vector<EventType> vector = null;

    private EventTypeManager() { // 保护构造函数
        refreshVector(); // 更新事件类型
    }

    // 获取单例的方法
    public static EventTypeManager getSingletonInstance() {
        if (eventTypeManager == null) { // 若单例为空则创建该单例
            eventTypeManager = new EventTypeManager();
        }
        return eventTypeManager; // 返回单例
    }

    // 将事件类型增加至数据库
    public int add(EventType eventType) {
        if (!validate(eventType)) // 验证事件类型是否合法，不合法则返回信息丢失
            return INFO_LOST;
        int statusCode = EventTypeDatabaseInterface.insert(eventType.getName(), eventType.getIcon()); // 向数据库中修改
        refreshVector(); // 更新事件类型容器
        Logger.Log(LOGFILE_PATH, "增加事件类型" + eventType.getName() + "状态：" + statusCode);
        return statusCode;
    }

    // 将事件类型在数据库中修改
    public int modify(EventType eventType, EventType newEventType) {
        if (!validate(eventType)) // 验证事件类型是否合法，不合法则返回信息丢失
            return INFO_LOST;
        if (!validate(newEventType)) // 验证新事件类型是否合法，不合法则返回信息丢失
            return INFO_LOST;
        int statusCode = EventTypeDatabaseInterface.update(eventType.getName(), newEventType.getName(), newEventType.getIcon()); // 向数据库中修改
        refreshVector(); // 更新事件类型容器
        Logger.Log(LOGFILE_PATH, "修改事件类型" + eventType.getName() + "状态：" + statusCode);
        return statusCode;
    }

    // 将事件类型在数据库中删除
    public int remove(EventType eventType) {
        if (!validate(eventType)) // 验证事件类型是否合法，不合法则返回信息丢失
            return INFO_LOST;
        int statusCode = EventTypeDatabaseInterface.delete(eventType.getName()); // 向数据库中修改
        refreshVector(); // 更新事件类型容器
        Logger.Log(LOGFILE_PATH, "删除事件类型" + eventType.getName() + "状态：" + statusCode);
        return statusCode;
    }

    // 验证事件类型是否合法
    public boolean validate(EventType eventType) {
        if (eventType == null) { //若事件类型为空则不合法
            Logger.Log(LOGFILE_PATH, "验证事件类型失败，事件对象为空");
            return false;
        }
        if (eventType.getName() == null) { // 若事件类型名称为空则不合法
            Logger.Log(LOGFILE_PATH, "验证事件类型" + eventType.getName() + "失败，事件名称为空");
            return false;
        }
        if (eventType.getIcon() == null) { // 若事件类型图标地址为空则不合法
            Logger.Log(LOGFILE_PATH, "验证事件类型" + eventType.getName() + "失败，事件图标地址为空");
            return false;
        }
        Logger.Log(LOGFILE_PATH, "验证事件类型" + eventType.getName() + "通过");
        return true;
    }

    public void refreshVector() {
        vector = null; // 删除原有的vector
        vector = EventTypeDatabaseInterface.query(); // 从数据库中获取新的vector
    }

    public Vector<EventType> getVector() {
        return vector;
    }

    // 根据名字获取事件类型
    public EventType getEventTypeByName(String name) {
        // 遍历容器
        for (Iterator<EventType> iterator = vector.iterator(); iterator.hasNext();) {
            EventType eventType = iterator.next();
            if (eventType.getName().equals(name)) { // 若名字相等
                Logger.Log(LOGFILE_PATH, "查找事件类型" + name + "成功");
                return eventType;
            }
        }
        Logger.Log(LOGFILE_PATH, "查找事件类型" + name + "失败");
        return null;
    }
}
