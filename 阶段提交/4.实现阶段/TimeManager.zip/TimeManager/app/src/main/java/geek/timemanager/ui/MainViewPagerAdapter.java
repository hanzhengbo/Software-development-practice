package geek.timemanager.ui;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

/**
 * Created by 12191 on 2017/5/26.
 */

public class MainViewPagerAdapter extends PagerAdapter implements View.OnClickListener{

    private Activity activity;
    private List<View> viewList;

    public TimerPage timerPage;
    public RecordPage recordPage;
    public PlanPage planPage;
    public CountPage countPage;

    public MainViewPagerAdapter(Activity activity, List<View> viewList) {
        this.activity = activity;
        this.viewList = viewList;
        timerPage = new TimerPage(activity, this, viewList.get(Tab.TIMER_PAGE));
        recordPage = new RecordPage(activity, this, viewList.get(Tab.RECORD_PAGE));
        planPage = new PlanPage(activity, this, viewList.get(Tab.PLAN_PAGE));
        countPage = new CountPage(activity, this, viewList.get(Tab.COUNT_PAGE));
    }

    // 更新计时器界面
    public void notifyTimerPage() {

    }

    // 更新时间记录界面
    public void notifyRecordPage() {
        recordPage.notifyDataSetChanged();
    }

    // 更新时间规划界面
    public void notifyPlanPage() {
        planPage.notifyDataSetChanged();
    }

    // 更新时间统计界面
    public void notifyCountPage() {

    }

    // 初始化计时器页面
    private void initializeTimerPage() {
    }

    // 初始化时间记录页面
    private void initializeRecordPage() {

    }

    // 初始化时间规划页面
    private void initializePlanPage() {
    }

    // 初始化时间统计页面
    private void initializeCountPage() {
        countPage.getRecordView();
        countPage.getPlanView();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        switch (position) {
            case Tab.TIMER_PAGE:
                initializeTimerPage();
                break;
            case Tab.RECORD_PAGE:
                initializeRecordPage();
                break;
            case Tab.PLAN_PAGE:
                initializePlanPage();
                break;
            case Tab.COUNT_PAGE:
                initializeCountPage();
                break;
                default:
                    break;
        }
        View view = viewList.get(position);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView(viewList.get(position));
    }

    @Override
    public int getCount() {
        return viewList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void onClick(View v) {

    }
}
