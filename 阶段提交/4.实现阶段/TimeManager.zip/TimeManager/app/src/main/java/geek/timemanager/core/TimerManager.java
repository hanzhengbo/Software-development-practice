package geek.timemanager.core;

import android.os.Environment;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.di.TimeRecordDatabaseInterface;

/**
 * Created by 12191 on 2017/5/5.
 */
public class TimerManager {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static TimerManager timerManager = null; // 单例
    private final String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" +  "TimerManager.log"; // Log文件名称与路径
    private Vector<Timer> vector; // 当前正在计时的计时器

    private TimerManager() {
        Logger.Log(LOGFILE_PATH, "创建计时器管理器");
        refreshVector(); // 更新计时器容器
    }

    // 获取单例的方法
    public static TimerManager getSingletonInstance() {
        if (timerManager == null) { // 若单例为空则创建该单例
            timerManager = new TimerManager();
        }
        return timerManager; // 返回单例
    }

    // 增加计时器
    public int startTimer(EventType eventType) {
        Timer timer = new Timer(eventType.getName()); // 创建计时器并开始计时
        int statusCode = TimeRecordDatabaseInterface.insert(timer.getStartTime(), null, timer.getEventType(), null); // 更新至数据库
        if (statusCode > 0) {
            timer.setID(statusCode);
            Logger.Log(LOGFILE_PATH, "增加计时器" + timer.toLog() + "成功");
            refreshVector();
        } else {
            Logger.Log(LOGFILE_PATH, "增加计时器" + timer.getEventType() + "失败， 状态码： " + statusCode);
        }
        return statusCode;
    }

    // 修改计时器
    public int modifyTimer(Timer timer) {
        if (!validate(timer)) { // 验证计时器
            return INFO_LOST;
        }

        int statusCode = TimeRecordDatabaseInterface.update(timer.getID(), timer.getStartTime(), null, timer.getEventType(), null); // 更新至数据库
        Logger.Log(LOGFILE_PATH, "修改计时器" + timer.toLog() + " 状态码： " + statusCode);
        refreshVector(); // 更新容器
        return statusCode;
    }

    // 删除计时器
    public int stopTimer(Timer timer) {
        if (!validate(timer)) { // 验证计时器
            return INFO_LOST;
        }
        timer.stopTiming(); // 停止计时
        TimeRecord timeRecord = new TimeRecord(timer.getStartTime(), timer.getEndTime(), timer.getEventType(), null); // 创建时间记录
        timeRecord.setID(timer.getID()); // 更新ID
        TimeRecordManager timeRecordManager = TimeRecordManager.getSingletonInstance(); // 获取时间记录管理器
        int statusCode = timeRecordManager.modify(timeRecord); // 更新至数据库
        Logger.Log(LOGFILE_PATH, "停止计时器" + timer.toLog() + " 状态码： " + statusCode);
        refreshVector(); // 更新容器
        return  statusCode;// 更改时间记录
    }

    // 验证计时器
    public boolean validate(Timer timer) {
        if (timer == null) {
            Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器对象为空");
            return false;
        }
        if (timer.getID() == -1) {
            Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器ID错误");
            return false;
        }
        if (timer.getEventType() == null) {
            Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器事件类型为空");
            return false;
        }
        if (timer.getStartTime() == null) {
            Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器起始时间为空");
            return false;
        }
        if (timer.getStartTime().compareTo(new Timestamp(System.currentTimeMillis())) > 0) {
            Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器起始时间后于当前时间");
            return false;
        }
        if (timer.getEndTime() != null) {
            if (timer.getStartTime().compareTo(timer.getEndTime()) > 0) {
                Logger.Log(LOGFILE_PATH, "验证计时器失败，计时器结束时间为空");
                return false;
            }
        }
        Logger.Log(LOGFILE_PATH, "验证计时器通过");
        return true;
    }

    // 更新计时器容器
    public void refreshVector() {
        vector = TimeRecordDatabaseInterface.queryTimer(); // 获取当前正在计时的计时器
    }

    // 获取计时器容器
    public Vector<Timer> getAllTimer() {
        refreshVector(); // 更新容器
        return vector;
    }

    public static void main(String[] args) {
        TimerManager timerManager = TimerManager.getSingletonInstance();
        Vector<Timer> vector = timerManager.getAllTimer();
        for (Iterator<Timer> iterator = vector.iterator(); iterator.hasNext();) {
            System.out.println(iterator.next().toLog());
        }
    }
}
