package geek.timemanager.ui;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/26.
 */

public class SideBar implements View.OnClickListener {

    private Activity activity;

    private FragmentManager fragmentManager;
    private FragmentTransaction transaction;

    private List<Fragment> fragmentList;
    public MainFragment mainFragment;
    public EventTypeManageFragment eventTypeManageFragment;
    public SettingsFragment settingsFragment;

    private TextView mainTextView;
    private TextView eventTypeTextView;
    private TextView settingsTextView;

    public SideBar(Activity activity) {
        this.activity = activity;
        this.fragmentManager = activity.getFragmentManager();
        this.mainFragment = new MainFragment();
        this.eventTypeManageFragment = new EventTypeManageFragment();
        this.settingsFragment = new SettingsFragment();

        initializeView();
        initializeEvent();
    }

    // 初始化界面
    private void initializeView() {
        mainTextView = (TextView)activity.findViewById(R.id.id_layout_sidebar_menu_main);
        eventTypeTextView = (TextView)activity.findViewById(R.id.id_layout_sidebar_menu_event_type);
        settingsTextView = (TextView)activity.findViewById(R.id.id_layout_sidebar_menu_setting);
    }

    // 初始化事件
    private void initializeEvent() {
        fragmentList = new ArrayList<>();
        fragmentList.add(mainFragment);
        fragmentList.add(eventTypeManageFragment);
        fragmentList.add(settingsFragment);
        transaction = fragmentManager.beginTransaction();
        transaction.add(R.id.id_fragment_main, mainFragment);
        transaction.add(R.id.id_fragment_main, eventTypeManageFragment);
        transaction.add(R.id.id_fragment_main, settingsFragment);
        transaction.commit();
        hideAll();
        transaction = fragmentManager.beginTransaction();
        transaction.show(mainFragment);
        transaction.commit();

        mainTextView.setOnClickListener(this);
        eventTypeTextView.setOnClickListener(this);
        settingsTextView.setOnClickListener(this);
    }

    // 隐藏所有fragment
    private void hideAll() {
        transaction = fragmentManager.beginTransaction();
        for (Iterator<Fragment> iterator = fragmentList.iterator(); iterator.hasNext();) {
            transaction.hide(iterator.next());
        }
        transaction.commit();
    }

    @Override
    public void onClick(View v) {
        hideAll();
        transaction = fragmentManager.beginTransaction();
        switch (v.getId()) {
            case R.id.id_layout_sidebar_menu_main:
                transaction.show(mainFragment);
                break;
            case R.id.id_layout_sidebar_menu_event_type:
                transaction.show(eventTypeManageFragment);
                break;
            case R.id.id_layout_sidebar_menu_setting:
                transaction.show(settingsFragment);
                break;
                default:
                    break;
        }
        transaction.commit();
        DrawerLayout drawerLayout = (DrawerLayout)activity.findViewById(R.id.id_activity_main);
        drawerLayout.closeDrawer(Gravity.START);
    }
}
