package geek.timemanager.ui;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.prefs.BackingStoreException;

import geek.timemanager.R;

/**
 * Created by 12191 on 2017/5/27.
 */

public class EventTypeManageFragment extends Fragment {

    private Activity activity;
    private View view;

    private ImageView sidebarImageView;
    private ImageView addImageView;
    private ListView listView;
    private EventListAdapter eventListAdapter;

    private void initializeView() {
        sidebarImageView = (ImageView)view.findViewById(R.id.id_event_sidebar);
        addImageView = (ImageView)view.findViewById(R.id.id_event_add);
        listView = (ListView)view.findViewById(R.id.id_event_list);
    }

    private void initializeEvent() {

        sidebarImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrawerLayout drawerLayout = (DrawerLayout)activity.findViewById(R.id.id_activity_main);
                if (drawerLayout.isDrawerOpen(Gravity.START)) {
                    drawerLayout.closeDrawer(Gravity.START);
                } else {
                    drawerLayout.openDrawer(Gravity.START);
                }
            }
        });

        addImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, AddEventActivity.class);
                activity.startActivity(intent);
            }
        });

        eventListAdapter = new EventListAdapter(activity);
        listView.setAdapter(eventListAdapter);
    }

    public void notifyEventList() {
        eventListAdapter.notifyDataSetChanged();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.activity = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_event_type_manage, null);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.view = getView();
        initializeView();
        initializeEvent();
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}
