package geek.timemanager.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import geek.timemanager.core.TimeRecord;

/**.
 * Created by 12191 on 2017/5/28.
 */

public class RecordListItemListener implements View.OnClickListener {
    public static final String MODE_NAME = "mode";
    public static final String TIME_RECORD_NAME = "time-record";
    public static final String RECORD_PAGE_NAME = "record-page";

    private TimeRecord timeRecord;

    private Activity activity;

    public RecordListItemListener(Activity activity, TimeRecord timeRecord) {
        this.activity = activity;
        this.timeRecord = timeRecord;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(activity, ModifyRecordActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(TIME_RECORD_NAME, timeRecord);
        intent.putExtras(bundle);
        activity.startActivity(intent);
    }
}
