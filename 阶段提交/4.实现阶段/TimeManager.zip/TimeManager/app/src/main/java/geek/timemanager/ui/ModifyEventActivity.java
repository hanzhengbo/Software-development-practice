package geek.timemanager.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Iterator;
import java.util.Vector;

import geek.timemanager.R;
import geek.timemanager.core.EventType;
import geek.timemanager.core.EventTypeManager;
import geek.timemanager.core.TimePlan;
import geek.timemanager.core.TimePlanManager;
import geek.timemanager.core.TimeRecord;
import geek.timemanager.core.TimeRecordManager;
import geek.timemanager.di.TimePlanDatabaseInterface;
import geek.timemanager.di.TimeRecordDatabaseInterface;

/**
 * Created by 12191 on 2017/5/29.
 */

public class ModifyEventActivity extends Activity {
    private EventTypeManager eventTypeManager;
    private EventType eventType;
    private EventType newEventType;

    private ImageView backImageView;
    private ImageView deleteImageView;
    private ImageView confirmImageView;
    private ListView listView;
    private ModifyEventAdapter modifyEventAdapter;
    private EditText editText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_modify_event);
        getInfo();
        initializeView();
        initializeEvent();
    }

    private void getInfo() {
        Intent intent = this.getIntent();
        eventType = (EventType)intent.getSerializableExtra(EventListAdapter.EVENT_TYPE_NAME);
        eventTypeManager = EventTypeManager.getSingletonInstance();
    }

    private void initializeView() {
        backImageView = (ImageView)findViewById(R.id.id_event_back);
        deleteImageView = (ImageView)findViewById(R.id.id_event_delete);
        confirmImageView = (ImageView)findViewById(R.id.id_event_confirm);
        listView = (ListView)findViewById(R.id.id_event_icon_list);
        editText = (EditText)findViewById(R.id.id_modify_event_name);
    }

    private void initializeEvent() {
        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        deleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePlanManager timePlanManager = TimePlanManager.getSingletonInstance();
                TimeRecordManager timeRecordManager = TimeRecordManager.getSingletonInstance();
                eventTypeManager.remove(eventType);
                Vector<TimePlan> timePlanVector = TimePlanDatabaseInterface.query(eventType.getName());
                Vector<TimeRecord> timeRecordVector = TimeRecordDatabaseInterface.query(eventType.getName());
                for (Iterator<TimePlan> iterator = timePlanVector.iterator(); iterator.hasNext();) {
                    timePlanManager.remove(iterator.next());
                }
                for (Iterator<TimeRecord> iterator = timeRecordVector.iterator(); iterator.hasNext();) {
                    timeRecordManager.remove(iterator.next());
                }
                finish();
            }
        });

        confirmImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getModifiedEventType();
                if (!ValidateEventType()) {
                    return;
                }
                eventTypeManager.modify(eventType, newEventType);
                finish();
            }
        });

        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");
            }
        });

        modifyEventAdapter = new ModifyEventAdapter(eventType.getIcon(), this);
        listView.setAdapter(modifyEventAdapter);
    }

    private boolean ValidateEventType() {
        String name = newEventType.getName();
        if (name == null || name.equals("")) {
            Toast.makeText(this, "请输入事件名称", Toast.LENGTH_LONG).show();
            return false;
        }

        Vector<EventType> vector = eventTypeManager.getVector();
        for (Iterator<EventType> iterator = vector.iterator(); iterator.hasNext();) {
            if (iterator.next().getName().equals(name)) {
                Toast.makeText(this, "事件名称重复", Toast.LENGTH_LONG).show();
                return false;
            }
        }

        return true;
    }

    private void getModifiedEventType() {
        String icon = modifyEventAdapter.getIcon();
        String name = editText.getText().toString();
        newEventType = new EventType(name, icon);
    }
}
