package geek.timemanager.core;

import android.os.Environment;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Vector;

import geek.timemanager.di.TimePlanDatabaseInterface;

/**
 * Created by 12191 on 2017/5/1.
 */
public class TimePlanManager {

    private static final int SUCCESS = 0; // 返回0则代表成功
    private static final int INFO_LOST = -1; // 返回-1则代表信息不完整
    private static final int CONNECT_FAIL = -2; // 返回-2则代表连接数据库失败
    private static final int OPERATE_FAIL = -3; // 返回-3则代表连接数据库操作失败

    private static TimePlanManager timePlanManager = null; // 单例
    private String LOGFILE_PATH = Environment.getExternalStorageDirectory() + "/TimeManager/" +  "TimePlanManager.log"; // Log文件路径与名称
    private Vector<TimePlan> vector = null; // 保存当天的所有时间规划

    private TimePlanManager() { // 保护构造函数
        Logger.Log(LOGFILE_PATH, "创建时间规划管理器");
        refreshVector(); // 更新事件类型
    }

    // 获取单例的方法
    public static TimePlanManager getSingletonInstance() {
        if (timePlanManager == null) { // 若单例为空则创建该单例
            timePlanManager = new TimePlanManager();
        }
        return timePlanManager; // 返回单例
    }

    // 将时间规划增加至数据库
    public int add(TimePlan timePlan) {
        if (!validate(timePlan)) { // 若验证失败
            return INFO_LOST;
        }
        int statusCode = TimePlanDatabaseInterface.insert(timePlan.getStartTime(), timePlan.getEndTime(), timePlan.getEventType().toString(), timePlan.getNote()); // 更新至数据库
        if (statusCode >= 0) { // 新增成功返回的为ID
            Logger.Log(LOGFILE_PATH, "新增时间规划： " + timePlan.toLog() + " 成功");
            timePlan.setID(statusCode);
        } else {
            Logger.Log(LOGFILE_PATH, "新增时间规划： " + timePlan.getEventType() + " 失败，状态： " + statusCode);
        }
        return statusCode;
    }

    // 在数据库中修改时间规划
    public int modify(TimePlan timePlan) {
        if (!validate(timePlan)) { // 若验证失败
            return INFO_LOST;
        }

        if (timePlan.getID() == -1) { // 若验证ID失败
            Logger.Log(LOGFILE_PATH, "修改时间规划失败，ID错误");
            return INFO_LOST;
        }

        int statusCode = TimePlanDatabaseInterface.update(timePlan.getID(), timePlan.getStartTime(), timePlan.getEndTime(), timePlan.getEventType().toString(), timePlan.getNote()); // 更新至数据库
        Logger.Log(LOGFILE_PATH, "修改时间规划： " + timePlan.toLog() + " 状态： " + statusCode);
        return statusCode;
    }

    // 在数据库中删除时间规划
    public int remove(TimePlan timePlan) {
        if (!validate(timePlan)) { // 若验证失败
            return INFO_LOST;
        }

        if (timePlan.getID() == -1) { // 若验证ID失败
            Logger.Log(LOGFILE_PATH, "删除时间规划失败，ID错误");
            return INFO_LOST;
        }

        int statusCode = TimePlanDatabaseInterface.delete(timePlan.getID());
        Logger.Log(LOGFILE_PATH, "删除时间规划： " + timePlan.toLog() + " 状态： " + statusCode);
        return statusCode;
    }

    // 验证时间规划是否合法
    public boolean validate(TimePlan timePlan) {
        if (timePlan == null) { //若时间规划为空则不合法
            Logger.Log(LOGFILE_PATH, "验证时间规划失败，时间规划对象为空");
            return false;
        }
        if (timePlan.getEventType() == null) { //若事件类型为空则不合法
            Logger.Log(LOGFILE_PATH, "验证时间规划失败，时间规划事件类型为空");
            return false;
        }
        if (timePlan.getStartTime() == null) { // 若开始时间为空则不合法
            Logger.Log(LOGFILE_PATH, "验证时间规划失败，时间规划开始时间为空");
            return false;
        }
        if (timePlan.getEndTime() == null) { // 若结束时间为空则不合法
            Logger.Log(LOGFILE_PATH, "验证时间规划失败，时间规划结束时间为空");
            return false;
        }
        if (timePlan.getStartTime().compareTo(timePlan.getEndTime()) > 0) { //起始时间后于结束时间
            Logger.Log(LOGFILE_PATH, "验证时间规划失败，时间规划起始时间后于结束时间");
            return false;
        }
        Logger.Log(LOGFILE_PATH, "验证时间规划成功");
        return true;
    }

    // 更新时间规划容器
    public void refreshVector() {
//        Timestamp todayStart = new Timestamp(System.currentTimeMillis()); // 获取当前时间
//        todayStart.setHours(0); // 设置时间为当天起始时间
//        todayStart.setMinutes(0);
//        todayStart.setSeconds(0);
//        Timestamp todayEnd = new Timestamp(System.currentTimeMillis()); // 获取当前时间
//        todayEnd.setHours(23); // 设置时间为当天结束时间
//        todayEnd.setMinutes(59);
//        todayEnd.setSeconds(59);
//        vector = TimePlanDatabaseInterface.query(todayStart, todayEnd); // 获取当天时间规划
//        Logger.Log(LOGFILE_PATH, "更新当天时间规划");
        vector = TimePlanDatabaseInterface.query();
    }

    // 获取当天时间规划容器
    public Vector<TimePlan> getTodayVector() {
        return vector;
    }

    // 查找规定时间内的时间计划(精确到天)
    public Vector<TimePlan> query(Date dateStart, Date dateEnd) {
        if (dateStart == null || dateEnd == null) {
            Logger.Log(LOGFILE_PATH, "查找时间规划失败，信息不完整");
            return null;
        }
        Timestamp timestampStart = new Timestamp(dateStart.getTime());
        timestampStart.setHours(0); // 设置时间为当天起始时间
        timestampStart.setMinutes(0);
        timestampStart.setSeconds(0);
        Timestamp timestampEnd = new Timestamp(dateEnd.getTime());
        timestampEnd.setHours(23); // 设置时间为当天结束时间
        timestampEnd.setSeconds(59);
        timestampEnd.setMinutes(59);
        Vector<TimePlan> vector = TimePlanDatabaseInterface.query(timestampStart, timestampEnd); // 查找
        if (vector == null) {
            Logger.Log(LOGFILE_PATH, "查找时间规划失败，请查阅" + LOGFILE_PATH);
        } else {
            Logger.Log(LOGFILE_PATH, "查找时间规划成功");
        }
        return vector;
    }

    public static void main(String[] args) {
        TimePlanManager timePlanManager = TimePlanManager.getSingletonInstance();
        Timestamp start = new Timestamp(System.currentTimeMillis());
        Timestamp end = new Timestamp(System.currentTimeMillis());
        end.setMonth(5);
        TimePlan timePlan = new TimePlan(start, end, "上课", "hehe");
        timePlanManager.add(timePlan);
        timePlanManager.remove(timePlan);
    }
}
