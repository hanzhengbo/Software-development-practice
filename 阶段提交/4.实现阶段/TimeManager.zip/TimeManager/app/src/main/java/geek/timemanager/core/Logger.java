package geek.timemanager.core;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by 12191 on 2017/5/1.
 */
public class Logger {

    public static void Log(String logFile, String info) {
        try {
            File file = new File(logFile); // 打开log文件
            if (!file.exists()) { // 若文件不存在
                file.createNewFile(); // 新建文件
            }

            //获取随机读写文件的实例
            RandomAccessFile randomAccessFile =new RandomAccessFile(file, "rw");
            //获取连接到文件的通道
            FileChannel inChannel = randomAccessFile.getChannel();
            //将文件定位到结尾
            inChannel.position(inChannel.size());

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
            info = simpleDateFormat.format(new Date()) + ": " + info + "\n"; // 换行
            //在当前定位的位子上写入内容
            //将内容存入ByteBuffer
            // 采用GBK编码方式
            ByteBuffer sendBuffer=ByteBuffer.wrap(info.getBytes("GBK"));
            //将ByteBuffer放入文件通道
            inChannel.write(sendBuffer);

            //关闭资源
            sendBuffer.clear();
            inChannel.close();
            randomAccessFile.close();

        } catch (Exception e) {
            System.out.println("写入Log文件 " + logFile + " 失败"); // 控制台输出提示
            e.printStackTrace();
        }
    }
}
