package geek.timemanager.ui;

import java.util.Vector;

/**
 * Created by 12191 on 2017/5/30.
 */

public class Pictures {
    private static Pictures singletonInstances;

    private Vector<String> iconVector;
    private Vector<String> descriptionVector;

    public static Pictures getSingletonInstances() {
        if (singletonInstances == null) {
            singletonInstances = new Pictures();
        }
        return singletonInstances;
    }

    private Pictures() {
        initializeVectors();
    }

    private void initializeVectors(){
        iconVector = new Vector<>(); descriptionVector = new Vector<>();
        iconVector.add("chat"); descriptionVector.add("聊天 / 交流 / 对话");
        iconVector.add("code"); descriptionVector.add("设计 / 编码 / 工作");
        iconVector.add("fix"); descriptionVector.add("修理");
        iconVector.add("game"); descriptionVector.add("放松 / 游戏 / 休闲");
        iconVector.add("listen"); descriptionVector.add("放松 / 音乐 / 娱乐");
        iconVector.add("photo"); descriptionVector.add("摄影 / 爱好 / 休闲");
        iconVector.add("travel"); descriptionVector.add("旅行");
        iconVector.add("tv"); descriptionVector.add("电视 / 休闲");
        iconVector.add("web"); descriptionVector.add("报纸 / 上网");
        iconVector.add("work"); descriptionVector.add("上班 / 工作 / 出差");
    }

    public Vector<String> getIconVector() {
        return iconVector;
    }

    public Vector<String> getDescriptionVector() {
        return descriptionVector;
    }
}
